'''
Created on Mar 30, 2017

@author: chaoweizhang
'''
from nltk.corpus import PlaintextCorpusReader
corpus_root = 'txtFiles'
wordlists = PlaintextCorpusReader(corpus_root, '.*')
print wordlists.fileids()