import re ###    This part can be used to search words what you want with a format you established from text....
import nltk
print '***********This part can be used to search words what you want with a format you established from text....***********'


wordlist = [w for w in open('nagetive words.txt').read().split(' ') if w.islower()]
a = [w for w in wordlist if re.search('ed$', w)] # end with 'ed'
b = [w for w in wordlist if re.search('^..j..t..$', w)] # find the word which have the form of ..j..t..
c = [w for w in wordlist if re.search('^[ghi][mno][jlk][def]$', w)] #first letter is g or h or i, second letter...
chat_words = sorted(set(w for w in nltk.corpus.nps_chat.words()))




[w for w in wordlist if re.search('^m+i+n+e+$', w)]## mmmiiiineeeee
[w for w in wordlist if re.search('^[0-9]+\.[0-9]+$', w)] ## find all fractions  9.8
[w for w in wordlist if re.search('^[A-Z]+\$$', w)] ## 'C$', 'US$'
[w for w in wordlist if re.search('^[0-9]{4}$', w)] ## '1614', '1637', '1787', '1901', '1903'
[w for w in wordlist if re.search('^[0-9]+-[a-z]{3,5}$', w)] ##'10-day', '10-lap', '10-year', '100-share'
[w for w in wordlist if re.search('^[0-9]{4}$', w)] ## 1234 1991
[w for w in wordlist if re.search('^[a-z]{5,}-[a-z]{2,3}-[a-z]{,6}$', w)] ## 'black-and-white', 'bread-and-butter'
[w for w in wordlist if re.search('(ed|ing)$', w)] ## end with ed or ing.. 'Absorbed', 'According'


wsj = sorted(set(nltk.corpus.treebank.words()))
fd = nltk.FreqDist(vs for word in wsj
                    for vs in re.findall(r'[aeiou]{2,}', word)) ## findall 
#print fd.most_common(12) # the result is [('io', 549), ('ea', 476), ('ie', 331), ('ou', 329), ('ai', 261), ('ia', 253), ('ee', 217), ('oo', 174), ('ua', 109), ('au', 106), ('ue', 105), ('ui', 95)]
print type(nltk.corpus.udhr.words('English-Latin1')[:75])

from random import randint

def segment(text, segs):
    words = []
    last = 0
    for i in range(len(segs)):
        if segs[i] == '1':
            words.append(text[last:i+1])
            last = i+1
    words.append(text[last:])
    return words

def evaluate(text, segs):
    words = segment(text, segs)
    text_size = len(words)
    lexicon_size = sum(len(word) + 1 for word in set(words))
    return text_size + lexicon_size

def flip(segs, pos):
    return segs[:pos] + str(1-int(segs[pos])) + segs[pos+1:]

def flip_n(segs, n):
    for i in range(n):
        segs = flip(segs, randint(0, len(segs)-1))
    return segs

def anneal(text, segs, iterations, cooling_rate):
    temperature = float(len(segs))
    while temperature > 0.5:
        best_segs, best = segs, evaluate(text, segs)
        for i in range(iterations):
            guess = flip_n(segs, round(temperature))
            score = evaluate(text, guess)
            if score < best:
                best, best_segs = score, guess
        score, segs = best, best_segs
        temperature = temperature / cooling_rate
        print(evaluate(text, segs), segment(text, segs))
    print()
    return segs
text1 = "doyouseethekittyseethedoggydoyoulikethekittylikethedoggy"
seg1 = "0000000000000001000000000010000000000000000100000000000"

silly = ['We', 'called', 'him', 'Tortoise', 'because', 'he', 'taught', 'us', '.']
print type(''.join(silly))
print ('******************************')
fdist = nltk.FreqDist(['dog', 'cat', 'dog', 'cat', 'dog', 'snake', 'dog', 'cat'])
for word in sorted(fdist):
    print('1:', word, '->', fdist[word])
    print('2:','{}->{};'.format(word, fdist[word]))
    
print type(sorted(fdist))

print '{} wants a {} {}'.format ('Lee', 'sandwich', 'for lunch')




















