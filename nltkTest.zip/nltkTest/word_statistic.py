'''
Created on Mar 30, 2017

@author: chaoweizhang
'''
import nltk
import pylab
# import sys
# import site
# print sys.getdefaultencoding()
from nltk.corpus import PlaintextCorpusReader as pc
corpus_root = 'txtFiles'
wordlists = pc(corpus_root, '.*')
# print wordlists.fileids()
# print type(wordlists)
newordlists = []
finalwordlists = []
wordlist0=[] # count for file name
wordlist1=[] # count for the number of words of each file
wordlist2=[] # count for the number of sentences of each file
wordlist3=[] # count for the number of vocabularies of each file
wordlist4=[] # average word length
wordlist5=[] # average sentence length 
counter = 0
for fileid in wordlists.fileids():
    counter += 1
    num_chars = len(wordlists.raw(fileid))
    num_words = len(wordlists.words(fileid))
    num_sents = len(wordlists.sents(fileid))
    num_vocab = len(set(w.lower() for w in wordlists.words(fileid)))
#     print(round(num_chars), round(num_words), round(num_sents), round(num_vocab), fileid)
    newordlists.append(num_words)
    newordlists.append(fileid)
    wordlist0.append(counter)
    wordlist1.append(num_words)
    wordlist2.append(num_sents)
    wordlist3.append(num_vocab)
    wordlist4.append(round(num_chars/num_words))
    wordlist5.append(round(num_words/num_sents))
    finalwordlists.append(newordlists)
# print "********************************"
print finalwordlists
cfd = nltk.ConditionalFreqDist(
            (target, fileid[:4])
            for fileid in wordlists.fileids()
            for w in wordlists.words(fileid)
            for target in ['america', 'news'])
# print cfd
pylab.figure(1)
pylab.subplot(221), pylab.grid(True), pylab.plot(wordlist0, wordlist1, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('number of words')
pylab.subplot(222), pylab.grid(True), pylab.plot(wordlist0, wordlist2, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('number of sentences')
# print pylab.subplot(223), pylab.grid(True), pylab.plot(wordlist0, wordlist3, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('number of Vocabularies')
pylab.subplot(223), pylab.grid(True), pylab.plot(wordlist0, wordlist4, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('average word length')
pylab.subplot(224), pylab.grid(True), pylab.plot(wordlist0, wordlist5, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('average sentence length')
pylab.subplots_adjust(top=0.92, bottom=0.09, left=0.20, right=0.95, hspace=0.25,wspace=0.35)
print pylab.show()





