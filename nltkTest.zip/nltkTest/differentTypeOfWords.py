'''
Created on Apr 13, 2017

@author: chaoweizhang
'''
import pylab
import nltk
from nltk import word_tokenize
# import sys
# import site
# print sys.getdefaultencoding()
from nltk.corpus import PlaintextCorpusReader as pc
corpus_root = 'txtFiles'
wordlists = pc(corpus_root, '.*')

allWordslist = []
for fileid in wordlists.fileids():
    fullText = ''
    words = tuple(wordlists.words(fileid))
    for word in words:
        fullText = str(fullText + ' ' + word)
    allWordslist.append(fullText)  ### get all text in string type
list0 = []
list1 = [] # used to store the number of noun words in each text
list2 = [] # used to store the number of verb words in each text
list3 = [] # used to store the number of pronoun words in each text
list4 = []
count = 0
for eachText in allWordslist:
    text = word_tokenize(eachText)
    taggedText = nltk.pos_tag(text)
    count += 1
    word_tag_pairs = nltk.bigrams(taggedText)
    noun = 0.0
    verb = 0.0
    pronoun = 0.0
    adjective = 0.0
    for eachWord in taggedText:
        if eachWord[1] == 'NN':
            noun += 1
        if eachWord[1] == 'VBP':
            verb += 1
        if eachWord[1] == 'PRP':
            pronoun += 1
        if eachWord[1] == 'JJ':
            adjective += 1
    list0.append(count)
    list1.append(100*round(noun/len(taggedText),5))
    list2.append(100*round(verb/len(taggedText),5))
    list3.append(100*round(pronoun/len(taggedText),5))
    list4.append(100*round(adjective/len(taggedText),5))
pylab.figure(1)
pylab.subplot(221), pylab.grid(True), pylab.plot(list0, list1, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('percentage of noun words')
pylab.subplot(222), pylab.grid(True), pylab.plot(list0, list2, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('percentage of verb wordss')
# print pylab.subplot(223), pylab.grid(True), pylab.plot(wordlist0, wordlist3, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('number of Vocabularies')
pylab.subplot(223), pylab.grid(True), pylab.plot(list0, list3, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('percentage of pronoun words')
pylab.subplot(224), pylab.grid(True), pylab.plot(list0, list4, 'o'), pylab.xlabel('file sequence'), pylab.ylabel('percentage of adjective words')
pylab.subplots_adjust(top=0.92, bottom=0.09, left=0.10, right=0.95, hspace=0.25,wspace=0.35)
print pylab.show()
  
  
  
  
  
  
  
  
  
    