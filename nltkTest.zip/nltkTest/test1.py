'''
Created on Apr 13, 2017

@author: chaoweizhang
'''
import nltk
from nltk import word_tokenize
####### find the similar words from text
# text = nltk.Text(word.lower() for word in nltk.corpus.brown.words())  
# print text.similar('woman')
# print '******************'


####### important tech
# text = word_tokenize("They refuse to permit us to obtain the refuse permit")
# print nltk.pos_tag(text)
### result:[('They', 'PRP'), ('refuse', 'VBP'), ('to', 'TO'), ('permit', 'VB'), ('us', 'PRP'), ('to', 'TO'), ('obtain', 'VB'), ('the', 'DT'), ('refuse', 'NN'), ('permit', 'NN')]

print nltk.corpus.brown.tagged_words(tagset='universal')

from nltk.corpus import brown
brown_news_tagged = brown.tagged_words(categories='news', tagset='universal')
tag_fd = nltk.FreqDist(tag for (word, tag) in brown_news_tagged)
print type(tag_fd), type(brown_news_tagged)
print tag_fd.most_common()
word_tag_pairs = nltk.bigrams(brown_news_tagged)
noun_preceders = [a[1] for (a, b) in word_tag_pairs if b[1] == 'NOUN']
fdist = nltk.FreqDist(noun_preceders)
print [tag for (tag, _) in fdist.most_common()]


print type(brown.tagged_words)


a = [('1','1'), (''),'','']
print len(a)

a = 3.0
b = 5
print a/b






















