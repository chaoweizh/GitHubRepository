'''
Created on Apr 3, 2017

@author: chaoweizhang
'''
from nltk.corpus import PlaintextCorpusReader as pc
corpus_root = 'txtFiles'
wordlists = pc(corpus_root, '.*')
nagetiveList = []
positiveList = []

for nagetiveWords in open('nagetive words.txt').read().split(' '):
        nagetiveList.append(nagetiveWords)   
for positiveWords in open('positive words.txt').read().split(' '):
        positiveList.append(positiveWords)
nagetiveCountList = []
positiveCountList = []
fileNumber = []
counter = 0
neg_affectList = []
pos_affectList = []
# print len(open('nagetive words.txt').read().split(' '))
# print len(open('positive words.txt').read().split(' '))
for fileid in wordlists.fileids():
    raws = wordlists.raw(fileid)
    nagetiveCount = 0
    positiveCount = 0
    counter += 1
    neg_affect = 0.000
    pos_affect = 0.000
    fileNumber.append(counter)
#     print type(raws), len(raws), type(wordlists.raw(fileid))
#     print wordlists.raw(fileid).split(" ")[0]
    for words in raws.split(" "):
        if words in nagetiveList:
            nagetiveCount += 1
        neg_affect = round(float(nagetiveCount)/float(len(raws.split(" "))),5)
        if words in positiveList:
            positiveCount += 1
        pos_affect = round(float(positiveCount)/float(len(raws.split(" "))),5)
    nagetiveCountList.append(round((nagetiveCount),3))
    positiveCountList.append(round((positiveCount),3))
    neg_affectList.append(neg_affect)
    pos_affectList.append(pos_affect)
print neg_affectList
print pos_affectList
import pylab
pylab.figure(1)
pylab.subplot(221), pylab.grid(True), pylab.plot(fileNumber, nagetiveCountList, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('Number of negative word')
pylab.subplot(222), pylab.grid(True), pylab.plot(fileNumber, positiveCountList, 'o'), pylab.xlabel('file sequences'), pylab.ylabel('Number of positive words')  
pylab.subplot(223), pylab.grid(True), pylab.plot(fileNumber, neg_affectList, 'or'), pylab.xlabel('file sequence'), pylab.ylabel('ratio of negative word')
pylab.subplot(224), pylab.grid(True), pylab.plot(fileNumber, pos_affectList, 'o'), pylab.xlabel('file sequences'), pylab.ylabel('ratio of positive words')     
pylab.subplots_adjust(top=0.92, bottom=0.09, left=0.20, right=0.95, hspace=0.25,wspace=0.35)
print pylab.show()
            